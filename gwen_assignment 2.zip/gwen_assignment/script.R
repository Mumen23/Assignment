# Load necessary libraries
library(readr)

# 1. Unzip the folder
unzip_folder <- function(zip_file, output_dir) {
  tryCatch({
    unzip(zip_file, exdir = output_dir)
    print(paste("Unzipped folder at:", output_dir))
  }, error = function(e) {
    print(paste("Error unzipping folder:", e))
  })
}

# 2. Load and display CSV
display_data <- function(csv_file) {
  tryCatch({
    data <- read_csv(csv_file)
    print(head(data)) # Display the first few rows
  }, error = function(e) {
    print(paste("Error reading CSV:", e))
  })
}

# Example Usage
zip_file <- "Employee Profile.zip"
output_dir <- "Employee_Profile"

unzip_folder(zip_file, output_dir)

# Specify the CSV file to load
csv_file <- file.path(output_dir, "example_employee_details.csv")
display_data(csv_file)
