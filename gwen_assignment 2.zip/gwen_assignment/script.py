# Import necessary libraries
import pandas as pd
import os
import zipfile

# 1. Import Data
def load_data(file_path):
    try:
        data = pd.read_csv(file_path)
        print("Data loaded successfully!")
        return data
    except FileNotFoundError:
        print("File not found. Please check the path.")
    except Exception as e:
        print(f"An error occurred: {e}")

# 2. Create Employee Function
def get_employee_details(data, employee_name):
    try:
        employee = data[data['EmployeeName'].str.contains(employee_name, case=False, na=False)]
        if not employee.empty:
            return employee
        else:
            print("Employee not found.")
    except KeyError:
        print("Invalid column name.")
    except Exception as e:
        print(f"An error occurred: {e}")

# 3. Data Processing with Dictionary
def process_data_to_dict(data):
    try:
        return data.set_index('EmployeeName').to_dict(orient='index')
    except KeyError:
        print("Key column not found.")
    except Exception as e:
        print(f"An error occurred: {e}")

# 4. Error Handling is integrated into all functions.

# 5. Export Employee Details
def export_to_csv(data, employee_name, output_folder="Employee Profile"):
    os.makedirs(output_folder, exist_ok=True)
    file_name = os.path.join(output_folder, f"{employee_name}_details.csv")
    try:
        employee = get_employee_details(data, employee_name)
        if employee is not None:
            employee.to_csv(file_name, index=False)
            print(f"File saved at {file_name}")
            
            # Zip the folder
            with zipfile.ZipFile(f"{output_folder}.zip", 'w') as zf:
                for root, _, files in os.walk(output_folder):
                    for file in files:
                        zf.write(os.path.join(root, file))
            print(f"Zipped folder created: {output_folder}.zip")
    except Exception as e:
        print(f"An error occurred: {e}")

#1 
# print(load_data('salaries.csv'))
data = load_data('salaries.csv')
# print(get_employee_details(data, 'NATHANIEL FORD'))

export_to_csv(data, "NATHANIEL FORD")